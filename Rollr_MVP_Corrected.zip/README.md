# Rollr MVP (Corrected Structure)

## Deploy Instructions:
1. Upload this folder to a GitHub repository.
2. Go to Vercel, click 'New Project', import this repo.
3. Click 'Deploy' (no config changes needed).
4. Your live site will be available instantly.

Once live, proceed to connect Stripe and Supabase.
