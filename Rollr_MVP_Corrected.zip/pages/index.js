export default function Home() {
  return (
    <div style={{ textAlign: "center", padding: "100px", fontFamily: "sans-serif" }}>
      <h1>Rollr</h1>
      <p>Get Funded to Bet Sports. Keep 80% of Profits. Risk $0.</p>
      <button style={{ padding: "10px 20px", fontSize: "16px" }}>Get Started</button>
    </div>
  );
}
